export { ProfDashboardPage } from './ProfDashboardPage';
export { ProfAgendaPage } from './ProfAgendaPage';
export { ProfPatientsPage } from './ProfPatientsPage';
export { ProfPatientChartPage } from './ProfPatientChartPage';
export { ProfInvitesPage } from './ProfInvitesPage';
export { ProfSettingsPage } from './ProfSettingsPage';
