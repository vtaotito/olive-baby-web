// Olive Baby Web - API Service
import axios from 'axios';
import type { AxiosError, AxiosInstance, InternalAxiosRequestConfig } from 'axios';
import { storage } from '../lib/utils';
import type { AuthTokens, ApiResponse } from '../types';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api/v1';

// Create axios instance
const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor - add auth token
api.interceptors.request.use(
  (config: InternalAxiosRequestConfig) => {
    const tokens = storage.get<AuthTokens>('auth_tokens');
    if (tokens?.accessToken) {
      config.headers.Authorization = `Bearer ${tokens.accessToken}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle token refresh and error logging
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<ApiResponse>) => {
    const originalRequest = error.config as InternalAxiosRequestConfig & { _retry?: boolean };
    const status = error.response?.status;

    // Log 404 and 502 errors para debug
    if (status === 404) {
      const url = originalRequest?.url || 'unknown';
      console.warn(`[API 404] Rota não encontrada: ${originalRequest?.method?.toUpperCase()} ${url}`);
    } else if (status === 502) {
      console.error('[API 502] Bad Gateway - Servidor backend não está respondendo');
    } else if (status && status >= 500) {
      console.error(`[API ${status}] Erro no servidor: ${error.response?.data?.message || 'Erro interno'}`);
    }

    // If 401 and not already retrying
    if (status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const tokens = storage.get<AuthTokens>('auth_tokens');
        if (tokens?.refreshToken) {
          // Try to refresh token
          const response = await axios.post<ApiResponse<AuthTokens>>(
            `${API_URL}/auth/refresh`,
            { refreshToken: tokens.refreshToken }
          );

          if (response.data.success && response.data.data) {
            // Save new tokens
            storage.set('auth_tokens', response.data.data);
            
            // Retry original request
            originalRequest.headers.Authorization = `Bearer ${response.data.data.accessToken}`;
            return api(originalRequest);
          }
        }
      } catch (refreshError) {
        // Refresh failed - clear auth and redirect to login
        storage.remove('auth_tokens');
        storage.remove('user');
        window.location.href = '/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

export default api;

// ====== Auth Service ======
export const authService = {
  login: async (email: string, password: string) => {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
  },

  register: async (data: {
    email: string;
    password: string;
    fullName: string;
    cpf: string;
    phone?: string;
  }) => {
    const response = await api.post('/auth/register', data);
    return response.data;
  },

  refresh: async (refreshToken: string) => {
    const response = await api.post('/auth/refresh', { refreshToken });
    return response.data;
  },

  logout: async (refreshToken: string) => {
    const response = await api.post('/auth/logout', { refreshToken });
    return response.data;
  },

  forgotPassword: async (email: string) => {
    const response = await api.post('/auth/forgot-password', { email });
    return response.data;
  },

  resetPassword: async (token: string, password: string) => {
    const response = await api.post('/auth/reset-password', { token, password });
    return response.data;
  },

  getProfile: async () => {
    const response = await api.get('/auth/me');
    return response.data;
  },
};

// ====== Baby Service ======
export const babyService = {
  list: async () => {
    const response = await api.get('/babies');
    return response.data;
  },

  get: async (id: number) => {
    const response = await api.get(`/babies/${id}`);
    return response.data;
  },

  create: async (data: {
    name: string;
    birthDate: string;
    relationship: string;
    birthWeightGrams?: number;
    birthLengthCm?: number;
    city?: string;
    state?: string;
  }) => {
    const response = await api.post('/babies', data);
    return response.data;
  },

  update: async (id: number, data: Partial<{
    name: string;
    birthDate: string;
    city: string;
    state: string;
  }>) => {
    const response = await api.patch(`/babies/${id}`, data);
    return response.data;
  },

  delete: async (id: number) => {
    const response = await api.delete(`/babies/${id}`);
    return response.data;
  },
};

// ====== Routine Service ======
export const routineService = {
  // Feeding
  startFeeding: async (babyId: number, meta: Record<string, unknown>) => {
    const response = await api.post('/routines/feeding/start', { babyId, meta });
    return response.data;
  },

  closeFeeding: async (babyId: number, meta?: Record<string, unknown>, notes?: string) => {
    const response = await api.post('/routines/feeding/close', { babyId, meta, notes });
    return response.data;
  },

  // Sleep
  startSleep: async (babyId: number, meta?: Record<string, unknown>) => {
    const response = await api.post('/routines/sleep/start', { babyId, meta });
    return response.data;
  },

  closeSleep: async (babyId: number, meta?: Record<string, unknown>, notes?: string) => {
    const response = await api.post('/routines/sleep/close', { babyId, meta, notes });
    return response.data;
  },

  // Diaper (instant)
  registerDiaper: async (babyId: number, meta: Record<string, unknown>, notes?: string) => {
    const response = await api.post('/routines/diaper', { babyId, meta, notes });
    return response.data;
  },

  // Bath
  startBath: async (babyId: number, meta?: Record<string, unknown>) => {
    const response = await api.post('/routines/bath/start', { babyId, meta });
    return response.data;
  },

  closeBath: async (babyId: number, meta?: Record<string, unknown>, notes?: string) => {
    const response = await api.post('/routines/bath/close', { babyId, meta, notes });
    return response.data;
  },

  // Milk Extraction
  startExtraction: async (babyId: number, meta?: Record<string, unknown>) => {
    const response = await api.post('/routines/extraction/start', { babyId, meta });
    return response.data;
  },

  closeExtraction: async (babyId: number, meta?: Record<string, unknown>, notes?: string) => {
    const response = await api.post('/routines/extraction/close', { babyId, meta, notes });
    return response.data;
  },

  // Get active routine (nota: apenas 'feeding' está implementado no backend)
  getActive: async (babyId: number, routineType: string) => {
    try {
      const response = await api.get(`/routines/${routineType}/active/${babyId}`);
      return response.data;
    } catch (error: any) {
      // Se for 404, significa que a rota não existe ou não há rotina ativa
      if (error.response?.status === 404) {
        console.debug(`Rota getActive não implementada para ${routineType} ou nenhuma rotina ativa`);
        return { success: false, data: null };
      }
      throw error;
    }
  },

  // List routines
  list: async (babyId: number, params?: {
    routineType?: string;
    startDate?: string;
    endDate?: string;
    page?: number;
    limit?: number;
  }) => {
    const response = await api.get('/routines', { 
      params: {
        ...params,
        babyId,
      }
    });
    return response.data;
  },

  // Get single routine
  get: async (routineId: number) => {
    const response = await api.get(`/routines/log/${routineId}`);
    return response.data;
  },

  // Update routine
  update: async (routineId: number, data: {
    startTime?: string;
    endTime?: string;
    notes?: string;
    meta?: Record<string, unknown>;
  }) => {
    const response = await api.patch(`/routines/log/${routineId}`, data);
    return response.data;
  },

  // Delete routine
  delete: async (routineId: number) => {
    const response = await api.delete(`/routines/log/${routineId}`);
    return response.data;
  },
};

// ====== Stats Service ======
export const statsService = {
  get: async (babyId: number, range: '24h' | '7d' | '30d' = '24h') => {
    const response = await api.get(`/stats/${babyId}`, { params: { range } });
    return response.data;
  },

  getHistory: async (babyId: number, type: string, days: number = 7) => {
    const response = await api.get(`/stats/${babyId}/history/${type}`, { params: { days } });
    return response.data;
  },
};

// ====== Growth Service ======
export const growthService = {
  getAll: async (babyId: number) => {
    const response = await api.get(`/babies/${babyId}/growth`);
    return response.data;
  },

  get: async (babyId: number, growthId: number) => {
    const response = await api.get(`/babies/${babyId}/growth/${growthId}`);
    return response.data;
  },

  create: async (babyId: number, data: {
    measurementDate: string;
    weightGrams?: number;
    lengthCm?: number;
    headCircumferenceCm?: number;
    notes?: string;
  }) => {
    const response = await api.post(`/babies/${babyId}/growth`, data);
    return response.data;
  },

  update: async (babyId: number, growthId: number, data: Partial<{
    measurementDate: string;
    weightGrams: number;
    lengthCm: number;
    headCircumferenceCm: number;
    notes: string;
  }>) => {
    const response = await api.patch(`/babies/${babyId}/growth/${growthId}`, data);
    return response.data;
  },

  delete: async (babyId: number, growthId: number) => {
    const response = await api.delete(`/babies/${babyId}/growth/${growthId}`);
    return response.data;
  },

  getLatest: async (babyId: number) => {
    const response = await api.get(`/babies/${babyId}/growth/latest`);
    return response.data;
  },
};

// ====== Milestone Service ======
export const milestoneService = {
  getAll: async (babyId: number, params?: {
    category?: string;
  }) => {
    try {
      const response = await api.get(`/babies/${babyId}/milestones`, { params });
      return response.data;
    } catch (error: any) {
      // Se for 404, pode ser que a rota não exista ainda no backend
      if (error.response?.status === 404) {
        console.warn(`Rota de milestones pode não estar implementada no backend para baby ${babyId}`);
      }
      throw error;
    }
  },

  get: async (babyId: number, milestoneId: number) => {
    const response = await api.get(`/babies/${babyId}/milestones/${milestoneId}`);
    return response.data;
  },

  create: async (babyId: number, data: {
    title: string;
    description?: string;
    category: string;
    achievedAt?: string;
    notes?: string;
  }) => {
    const response = await api.post(`/babies/${babyId}/milestones`, data);
    return response.data;
  },

  update: async (babyId: number, milestoneId: number, data: Partial<{
    title: string;
    description: string;
    notes: string;
    achievedAt: string;
  }>) => {
    const response = await api.patch(`/babies/${babyId}/milestones/${milestoneId}`, data);
    return response.data;
  },

  delete: async (babyId: number, milestoneId: number) => {
    const response = await api.delete(`/babies/${babyId}/milestones/${milestoneId}`);
    return response.data;
  },
};

// ====== Export Service ======
export const exportService = {
  routines: async (babyId: number, params?: {
    startDate?: string;
    endDate?: string;
    types?: string[];
  }) => {
    const response = await api.get(`/export/${babyId}/routines`, {
      params,
      responseType: 'blob',
    });
    return response.data;
  },

  growth: async (babyId: number) => {
    const response = await api.get(`/export/${babyId}/growth`, {
      responseType: 'blob',
    });
    return response.data;
  },

  milestones: async (babyId: number) => {
    const response = await api.get(`/export/${babyId}/milestones`, {
      responseType: 'blob',
    });
    return response.data;
  },

  fullReport: async (babyId: number) => {
    const response = await api.get(`/export/${babyId}/full`, {
      responseType: 'blob',
    });
    return response.data;
  },
};

// ====== Professional Service ======
export const professionalService = {
  // Get professionals linked to a baby
  getByBaby: async (babyId: number) => {
    const response = await api.get(`/babies/${babyId}/professionals`);
    return response.data;
  },

  // Get professional details
  get: async (professionalId: number) => {
    const response = await api.get(`/professionals/${professionalId}`);
    return response.data;
  },

  // Invite a professional
  invite: async (babyId: number, data: {
    email: string;
    fullName: string;
    specialty: string;
    role: 'PEDIATRICIAN' | 'OBGYN' | 'LACTATION_CONSULTANT' | 'OTHER';
    crmNumber?: string;
    crmState?: string;
    phone?: string;
    notes?: string;
  }) => {
    const response = await api.post(`/babies/${babyId}/professionals/invite`, data);
    return response.data;
  },

  // Verify invite token (public)
  verifyToken: async (token: string) => {
    const response = await api.post('/professionals/verify-token', { token });
    return response.data;
  },

  // Activate professional account (public)
  activate: async (data: {
    token: string;
    password: string;
    phone?: string;
    city?: string;
    state?: string;
  }) => {
    const response = await api.post('/professionals/activate', data);
    return response.data;
  },

  // Resend invite
  resendInvite: async (babyId: number, professionalId: number) => {
    const response = await api.post(`/babies/${babyId}/professionals/${professionalId}/resend-invite`);
    return response.data;
  },

  // Remove professional from baby
  remove: async (babyId: number, linkId: number) => {
    const response = await api.delete(`/babies/${babyId}/professionals/${linkId}`);
    return response.data;
  },

  // Update professional link (notes, role)
  updateLink: async (babyId: number, linkId: number, data: {
    notes?: string;
    role?: 'PEDIATRICIAN' | 'OBGYN' | 'LACTATION_CONSULTANT' | 'OTHER';
  }) => {
    const response = await api.patch(`/babies/${babyId}/professionals/${linkId}`, data);
    return response.data;
  },

  // Get babies for professional (professional dashboard)
  getMyPatients: async () => {
    const response = await api.get('/professionals/my-patients');
    return response.data;
  },
};
